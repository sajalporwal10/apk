// Camarilla Stock Screener - Main Application

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  TouchableOpacity,
  StatusBar,
  SafeAreaView,
  RefreshControl,
  Alert,
  ActivityIndicator,
} from 'react-native';

import { StockData } from './src/types';
import { StockListItem, StockDetailsModal, ScanProgress } from './src/components';
import { scanAllStocks } from './src/services/api';
import { saveScanResults, loadCachedResults, getCacheTimestamp } from './src/services/storage';
import { exportToCSV } from './src/services/export';
import { getLastCompletedMonth } from './src/utils/calculations';

export default function App() {
  const [stocks, setStocks] = useState<StockData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState({ current: 0, total: 0, ticker: '' });
  const [selectedStock, setSelectedStock] = useState<StockData | null>(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [lastScanDate, setLastScanDate] = useState<Date | null>(null);
  const [isExporting, setIsExporting] = useState(false);

  const cancelRef = useRef(false);

  // Load cached results on app start
  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      const cached = await loadCachedResults();
      const timestamp = await getCacheTimestamp();

      if (cached && cached.length > 0) {
        setStocks(cached);
        setLastScanDate(timestamp);
      }
    } catch (error) {
      console.error('Error loading cached data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartScan = useCallback(async () => {
    if (isScanning) {
      // Cancel the scan
      cancelRef.current = true;
      return;
    }

    setIsScanning(true);
    cancelRef.current = false;
    setScanProgress({ current: 0, total: 0, ticker: '' });

    try {
      const results = await scanAllStocks(
        (current, total, ticker) => {
          setScanProgress({ current, total, ticker });
        },
        () => cancelRef.current
      );

      if (!cancelRef.current) {
        setStocks(results);
        await saveScanResults(results);
        setLastScanDate(new Date());

        Alert.alert(
          'Scan Complete',
          `Found ${results.length} stocks with narrow range (< 6.5%)`,
          [{ text: 'OK' }]
        );
      }
    } catch (error) {
      console.error('Scan error:', error);
      Alert.alert(
        'Scan Failed',
        'Could not fetch stock data. Please check your internet connection.',
        [{ text: 'OK' }]
      );
    } finally {
      setIsScanning(false);
      cancelRef.current = false;
    }
  }, [isScanning]);

  const handleExport = async () => {
    if (stocks.length === 0) {
      Alert.alert('No Data', 'Run a scan first to get results to export.');
      return;
    }

    setIsExporting(true);
    try {
      await exportToCSV(stocks);
    } catch (error) {
      Alert.alert('Export Failed', 'Could not export data. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleStockPress = (stock: StockData) => {
    setSelectedStock(stock);
    setModalVisible(true);
  };

  const formatDate = (date: Date | null): string => {
    if (!date) return 'Never';
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const { label: refMonth } = getLastCompletedMonth();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0D0D14" />

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Camarilla Screener</Text>
          <Text style={styles.subtitle}>NIFTY 500 • {refMonth}</Text>
        </View>
        <View style={styles.headerButtons}>
          <TouchableOpacity
            style={[styles.exportButton, isExporting && styles.buttonDisabled]}
            onPress={handleExport}
            disabled={isExporting || stocks.length === 0}
          >
            {isExporting ? (
              <ActivityIndicator size="small" color="#0D0D14" />
            ) : (
              <Text style={styles.exportButtonText}>📤</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>

      {/* Stats Bar */}
      <View style={styles.statsBar}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{stocks.length}</Text>
          <Text style={styles.statLabel}>Stocks</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>&lt; 6.5%</Text>
          <Text style={styles.statLabel}>Range Filter</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{formatDate(lastScanDate).split(',')[0]}</Text>
          <Text style={styles.statLabel}>Last Scan</Text>
        </View>
      </View>

      {/* Scan Button */}
      <TouchableOpacity
        style={[styles.scanButton, isScanning && styles.scanButtonActive]}
        onPress={handleStartScan}
      >
        <Text style={styles.scanButtonText}>
          {isScanning ? '⏹ Stop Scan' : '🔍 Start Scan'}
        </Text>
      </TouchableOpacity>

      {/* Scan Progress */}
      {isScanning && (
        <ScanProgress
          current={scanProgress.current}
          total={scanProgress.total}
          currentTicker={scanProgress.ticker}
        />
      )}

      {/* Loading State */}
      {isLoading && !isScanning && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#00E676" />
          <Text style={styles.loadingText}>Loading cached results...</Text>
        </View>
      )}

      {/* Empty State */}
      {!isLoading && !isScanning && stocks.length === 0 && (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>📊</Text>
          <Text style={styles.emptyTitle}>No Results Yet</Text>
          <Text style={styles.emptyText}>
            Tap "Start Scan" to fetch NIFTY 500 stocks and calculate Camarilla levels
          </Text>
        </View>
      )}

      {/* Stock List */}
      {!isLoading && !isScanning && stocks.length > 0 && (
        <FlatList
          data={stocks}
          keyExtractor={(item) => item.ticker}
          renderItem={({ item }) => (
            <StockListItem stock={item} onPress={handleStockPress} />
          )}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={handleStartScan}
              tintColor="#00E676"
            />
          }
        />
      )}

      {/* Stock Details Modal */}
      <StockDetailsModal
        stock={selectedStock}
        visible={modalVisible}
        onClose={() => {
          setModalVisible(false);
          setSelectedStock(null);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0D0D14',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#FFFFFF',
    letterSpacing: 0.5,
  },
  subtitle: {
    fontSize: 14,
    color: '#888',
    marginTop: 4,
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  exportButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#00E676',
    alignItems: 'center',
    justifyContent: 'center',
  },
  exportButtonText: {
    fontSize: 20,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  statsBar: {
    flexDirection: 'row',
    backgroundColor: '#1E1E2E',
    marginHorizontal: 16,
    marginVertical: 12,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#2D2D3F',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#00E676',
  },
  statLabel: {
    fontSize: 11,
    color: '#888',
    marginTop: 4,
    textTransform: 'uppercase',
  },
  statDivider: {
    width: 1,
    backgroundColor: '#2D2D3F',
    marginVertical: 4,
  },
  scanButton: {
    backgroundColor: '#00E676',
    marginHorizontal: 16,
    marginVertical: 8,
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#00E676',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  scanButtonActive: {
    backgroundColor: '#FF5252',
  },
  scanButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#0D0D14',
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  loadingText: {
    color: '#888',
    fontSize: 16,
    marginTop: 16,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  emptyText: {
    fontSize: 15,
    color: '#888',
    textAlign: 'center',
    lineHeight: 22,
  },
  listContent: {
    paddingVertical: 8,
    paddingBottom: 24,
  },
});
