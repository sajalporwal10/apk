int foo()
{
  return 0x42;
}
