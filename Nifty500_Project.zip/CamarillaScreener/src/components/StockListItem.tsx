// Stock List Item Component

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { StockData } from '../types';

interface StockListItemProps {
    stock: StockData;
    onPress: (stock: StockData) => void;
}

export const StockListItem: React.FC<StockListItemProps> = ({ stock, onPress }) => {
    const getRangeColor = (pct: number | null): string => {
        if (pct === null) return '#888';
        if (pct < 2) return '#00E676';      // Bright green - very tight
        if (pct < 3) return '#69F0AE';      // Light green
        if (pct < 4) return '#FFD740';      // Amber
        if (pct < 5) return '#FF9100';      // Orange
        return '#FF5252';                    // Red - wider range
    };

    return (
        <TouchableOpacity
            style={styles.container}
            onPress={() => onPress(stock)}
            activeOpacity={0.7}
        >
            <View style={styles.leftSection}>
                <Text style={styles.ticker}>{stock.ticker.replace('.NS', '')}</Text>
                <Text style={styles.period}>{stock.yearMonth}</Text>
            </View>

            <View style={styles.middleSection}>
                <View style={styles.priceRow}>
                    <Text style={styles.label}>R3</Text>
                    <Text style={styles.value}>₹{stock.r3?.toLocaleString()}</Text>
                </View>
                <View style={styles.priceRow}>
                    <Text style={styles.label}>S3</Text>
                    <Text style={styles.value}>₹{stock.s3?.toLocaleString()}</Text>
                </View>
            </View>

            <View style={styles.rightSection}>
                <View style={[styles.rangeBadge, { backgroundColor: getRangeColor(stock.pctRangeR3) }]}>
                    <Text style={styles.rangeText}>{stock.pctRangeR3?.toFixed(2)}%</Text>
                </View>
            </View>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#1E1E2E',
        marginHorizontal: 16,
        marginVertical: 6,
        padding: 16,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: '#2D2D3F',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 5,
    },
    leftSection: {
        flex: 1,
    },
    ticker: {
        fontSize: 18,
        fontWeight: '700',
        color: '#FFFFFF',
        letterSpacing: 0.5,
    },
    period: {
        fontSize: 12,
        color: '#888',
        marginTop: 4,
    },
    middleSection: {
        flex: 1.2,
        paddingHorizontal: 12,
    },
    priceRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginVertical: 2,
    },
    label: {
        fontSize: 12,
        color: '#888',
        fontWeight: '500',
    },
    value: {
        fontSize: 14,
        color: '#E0E0E0',
        fontWeight: '600',
    },
    rightSection: {
        alignItems: 'flex-end',
    },
    rangeBadge: {
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 12,
        minWidth: 70,
        alignItems: 'center',
    },
    rangeText: {
        fontSize: 14,
        fontWeight: '700',
        color: '#000',
    },
});
