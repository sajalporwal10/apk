import flet as ft
from nifty500_app import main as app_main

if __name__ == "__main__":
    ft.app(target=app_main)
