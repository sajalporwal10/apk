// Progress indicator component for scanning

import React from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';

interface ScanProgressProps {
    current: number;
    total: number;
    currentTicker: string;
}

export const ScanProgress: React.FC<ScanProgressProps> = ({
    current,
    total,
    currentTicker
}) => {
    const progress = total > 0 ? (current / total) * 100 : 0;

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.title}>Scanning NIFTY 500</Text>
                <Text style={styles.counter}>{current} / {total}</Text>
            </View>

            <View style={styles.progressBarContainer}>
                <View style={[styles.progressBar, { width: `${progress}%` }]} />
            </View>

            <Text style={styles.currentTicker}>
                Analyzing: <Text style={styles.tickerName}>{currentTicker.replace('.NS', '')}</Text>
            </Text>

            <Text style={styles.hint}>
                ⏱ This may take 3-5 minutes for all 500 stocks
            </Text>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#1E1E2E',
        margin: 16,
        padding: 24,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: '#2D2D3F',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 16,
    },
    title: {
        fontSize: 18,
        fontWeight: '700',
        color: '#FFFFFF',
    },
    counter: {
        fontSize: 16,
        fontWeight: '600',
        color: '#00E676',
    },
    progressBarContainer: {
        height: 8,
        backgroundColor: '#2D2D3F',
        borderRadius: 4,
        overflow: 'hidden',
        marginBottom: 16,
    },
    progressBar: {
        height: '100%',
        backgroundColor: '#00E676',
        borderRadius: 4,
    },
    currentTicker: {
        fontSize: 14,
        color: '#888',
        marginBottom: 12,
    },
    tickerName: {
        color: '#E0E0E0',
        fontWeight: '600',
    },
    hint: {
        fontSize: 12,
        color: '#666',
        textAlign: 'center',
        marginTop: 8,
    },
});
