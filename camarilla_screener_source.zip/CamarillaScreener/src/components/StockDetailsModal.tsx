// Stock Details Modal Component

import React from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, ScrollView } from 'react-native';
import { StockData } from '../types';

interface StockDetailsModalProps {
    stock: StockData | null;
    visible: boolean;
    onClose: () => void;
}

export const StockDetailsModal: React.FC<StockDetailsModalProps> = ({
    stock,
    visible,
    onClose
}) => {
    if (!stock) return null;

    const DataRow = ({ label, value, highlight = false }: { label: string; value: string; highlight?: boolean }) => (
        <View style={styles.dataRow}>
            <Text style={styles.dataLabel}>{label}</Text>
            <Text style={[styles.dataValue, highlight && styles.highlightValue]}>{value}</Text>
        </View>
    );

    return (
        <Modal
            animationType="slide"
            transparent={true}
            visible={visible}
            onRequestClose={onClose}
        >
            <View style={styles.overlay}>
                <View style={styles.modalContainer}>
                    {/* Header */}
                    <View style={styles.header}>
                        <View>
                            <Text style={styles.ticker}>{stock.ticker.replace('.NS', '')}</Text>
                            <Text style={styles.subtitle}>NSE • {stock.yearMonth}</Text>
                        </View>
                        <TouchableOpacity style={styles.closeButton} onPress={onClose}>
                            <Text style={styles.closeText}>✕</Text>
                        </TouchableOpacity>
                    </View>

                    <ScrollView style={styles.content}>
                        {/* OHLC Section */}
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Monthly OHLC</Text>
                            <View style={styles.card}>
                                <DataRow label="Open" value={`₹${stock.open?.toLocaleString()}`} />
                                <DataRow label="High" value={`₹${stock.high?.toLocaleString()}`} />
                                <DataRow label="Low" value={`₹${stock.low?.toLocaleString()}`} />
                                <DataRow label="Close" value={`₹${stock.close?.toLocaleString()}`} />
                            </View>
                        </View>

                        {/* Camarilla Levels */}
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Camarilla Levels</Text>
                            <View style={styles.card}>
                                <DataRow label="Resistance 3 (R3)" value={`₹${stock.r3?.toLocaleString()}`} highlight />
                                <DataRow label="Support 3 (S3)" value={`₹${stock.s3?.toLocaleString()}`} highlight />
                            </View>
                        </View>

                        {/* Range Analysis */}
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Range Analysis</Text>
                            <View style={styles.rangeCard}>
                                <Text style={styles.rangeLabel}>R3-S3 Range</Text>
                                <Text style={styles.rangeValue}>{stock.pctRangeR3?.toFixed(2)}%</Text>
                                <Text style={styles.rangeDescription}>
                                    {stock.pctRangeR3 && stock.pctRangeR3 < 2.5
                                        ? '🔥 Very tight consolidation - High breakout potential'
                                        : stock.pctRangeR3 && stock.pctRangeR3 < 4
                                            ? '📊 Moderate consolidation - Watch for breakout'
                                            : '📉 Wider range - Less predictable'}
                                </Text>
                            </View>
                        </View>

                        {/* Formula Reference */}
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Formula Reference</Text>
                            <View style={styles.formulaCard}>
                                <Text style={styles.formulaText}>R3 = Close + (High - Low) × 1.1 / 4</Text>
                                <Text style={styles.formulaText}>S3 = Close - (High - Low) × 1.1 / 4</Text>
                            </View>
                        </View>
                    </ScrollView>
                </View>
            </View>
        </Modal>
    );
};

const styles = StyleSheet.create({
    overlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        justifyContent: 'flex-end',
    },
    modalContainer: {
        backgroundColor: '#0D0D14',
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        maxHeight: '85%',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 20,
        borderBottomWidth: 1,
        borderBottomColor: '#2D2D3F',
    },
    ticker: {
        fontSize: 28,
        fontWeight: '800',
        color: '#FFFFFF',
        letterSpacing: 1,
    },
    subtitle: {
        fontSize: 14,
        color: '#888',
        marginTop: 4,
    },
    closeButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: '#2D2D3F',
        alignItems: 'center',
        justifyContent: 'center',
    },
    closeText: {
        fontSize: 18,
        color: '#888',
    },
    content: {
        padding: 20,
    },
    section: {
        marginBottom: 24,
    },
    sectionTitle: {
        fontSize: 14,
        fontWeight: '600',
        color: '#888',
        textTransform: 'uppercase',
        letterSpacing: 1,
        marginBottom: 12,
    },
    card: {
        backgroundColor: '#1E1E2E',
        borderRadius: 16,
        padding: 16,
        borderWidth: 1,
        borderColor: '#2D2D3F',
    },
    dataRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#2D2D3F',
    },
    dataLabel: {
        fontSize: 15,
        color: '#888',
    },
    dataValue: {
        fontSize: 16,
        fontWeight: '600',
        color: '#E0E0E0',
    },
    highlightValue: {
        color: '#00E676',
        fontWeight: '700',
    },
    rangeCard: {
        backgroundColor: '#1A1A2E',
        borderRadius: 16,
        padding: 24,
        alignItems: 'center',
        borderWidth: 2,
        borderColor: '#00E676',
    },
    rangeLabel: {
        fontSize: 14,
        color: '#888',
        marginBottom: 8,
    },
    rangeValue: {
        fontSize: 48,
        fontWeight: '800',
        color: '#00E676',
    },
    rangeDescription: {
        fontSize: 14,
        color: '#E0E0E0',
        marginTop: 12,
        textAlign: 'center',
    },
    formulaCard: {
        backgroundColor: '#1E1E2E',
        borderRadius: 16,
        padding: 16,
        borderWidth: 1,
        borderColor: '#2D2D3F',
    },
    formulaText: {
        fontSize: 13,
        fontFamily: 'monospace',
        color: '#69F0AE',
        paddingVertical: 4,
    },
});
